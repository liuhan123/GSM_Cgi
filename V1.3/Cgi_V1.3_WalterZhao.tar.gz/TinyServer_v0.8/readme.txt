1.目录结构：
Makefile用于编译，产生httpd文件，./httpd用于启动Web服务器
htdocs目录中存放index.htm和main.cgi文件。这两个文件的名字不要改动
2.输出文件
电话号码：number.txt
短息内容：message.txt
